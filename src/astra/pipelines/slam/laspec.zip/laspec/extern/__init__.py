__all__ = ['interpolate', 'polynomial']
