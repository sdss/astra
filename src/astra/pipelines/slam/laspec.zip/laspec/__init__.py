import os

PACKAGE_PATH = os.path.dirname(__file__)
